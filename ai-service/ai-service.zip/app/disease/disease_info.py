"""
Disease information database.
Maps disease class names (matching PlantVillage dataset labels) to
human-readable info: symptoms, treatment, prevention.

When you train the real model, make sure CLASS_NAMES order matches
your training generator's class_indices exactly.
"""

DISEASE_INFO = {
    "Tomato___Late_blight": {
        "disease_name": "Tomato Late Blight",
        "symptoms": "Dark, water-soaked spots on leaves that grow rapidly; white fungal growth on undersides in humid conditions; brown lesions on stems and fruit.",
        "treatment": "Apply copper-based fungicide (e.g. copper oxychloride) every 7-10 days. Remove and destroy infected plant parts immediately.",
        "prevention": "Avoid overhead watering. Ensure good air circulation between plants. Rotate crops yearly. Use resistant varieties where available."
    },
    "Tomato___Early_blight": {
        "disease_name": "Tomato Early Blight",
        "symptoms": "Concentric dark rings on older leaves (target-spot pattern), yellowing around lesions, leaf drop starting from the bottom of the plant.",
        "treatment": "Apply fungicide containing chlorothalonil or mancozeb. Remove infected lower leaves promptly.",
        "prevention": "Mulch around base to prevent soil splash onto leaves. Space plants for airflow. Avoid wetting foliage when watering."
    },
    "Tomato___healthy": {
        "disease_name": "Healthy",
        "symptoms": "No visible disease symptoms detected.",
        "treatment": "No treatment needed.",
        "prevention": "Continue regular monitoring, balanced fertilization, and proper irrigation."
    },
    "Potato___Late_blight": {
        "disease_name": "Potato Late Blight",
        "symptoms": "Dark blotches on leaves with pale green halos, rapid wilting, white mold under leaves in moist weather, tuber rot in storage.",
        "treatment": "Apply systemic fungicide (e.g. metalaxyl-based). Destroy infected foliage; harvest early if outbreak is severe.",
        "prevention": "Plant certified disease-free seed potatoes. Hill soil around stems. Avoid excess nitrogen fertilizer."
    },
    "Potato___Early_blight": {
        "disease_name": "Potato Early Blight",
        "symptoms": "Brown concentric-ring spots on older leaves, yellowing tissue around lesions, reduced tuber size.",
        "treatment": "Apply mancozeb or chlorothalonil-based fungicide at first sign of spots.",
        "prevention": "Maintain consistent watering to reduce plant stress. Rotate with non-solanaceous crops."
    },
    "Potato___healthy": {
        "disease_name": "Healthy",
        "symptoms": "No visible disease symptoms detected.",
        "treatment": "No treatment needed.",
        "prevention": "Continue regular monitoring and balanced fertilization."
    },
    "Corn___Common_rust": {
        "disease_name": "Corn Common Rust",
        "symptoms": "Small, reddish-brown circular to elongated pustules on both leaf surfaces; severe infections cause leaf yellowing and early death.",
        "treatment": "Apply triazole or strobilurin fungicide if infection is severe and detected early in the season.",
        "prevention": "Plant resistant hybrids. Avoid late planting. Monitor fields regularly during humid weather."
    },
    "Corn___healthy": {
        "disease_name": "Healthy",
        "symptoms": "No visible disease symptoms detected.",
        "treatment": "No treatment needed.",
        "prevention": "Continue regular monitoring and balanced fertilization."
    },
}

# Full PlantVillage class list (38 classes) - placeholder order.
# IMPORTANT: replace this with your actual trained model's class_indices
# (from train_generator.class_indices) once you train the real model.
CLASS_NAMES = list(DISEASE_INFO.keys())


def get_disease_info(class_name: str) -> dict:
    """Look up disease info by class name, with a safe fallback."""
    return DISEASE_INFO.get(class_name, {
        "disease_name": class_name.replace("_", " ").replace("___", " - "),
        "symptoms": "Symptom information not yet available for this class.",
        "treatment": "Consult a local agricultural extension officer for treatment guidance.",
        "prevention": "Practice crop rotation and field sanitation as general prevention."
    })
