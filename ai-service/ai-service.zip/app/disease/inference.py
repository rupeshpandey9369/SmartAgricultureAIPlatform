"""
Disease detection inference.

CURRENT STATE: Dummy inference using basic image statistics, so the full
upload -> predict -> response pipeline works end-to-end before a real
model is trained.

TO MAKE THIS REAL (Phase 3.5):
1. Train an EfficientNetB0 model on PlantVillage dataset (see training/ folder, to be added)
2. Save trained model as app/disease/model/disease_model.h5
3. Uncomment the TensorFlow loading code below
4. Replace `_dummy_predict()` calls with `_real_predict()`
5. Update disease_info.CLASS_NAMES to match your training class_indices order
"""

import io
import random
from PIL import Image
import numpy as np

from app.disease.disease_info import CLASS_NAMES, get_disease_info

# ---------------------------------------------------------------------
# REAL MODEL LOADING (commented out until you train and drop in a model)
# ---------------------------------------------------------------------
# import tensorflow as tf
# MODEL_PATH = "app/disease/model/disease_model.h5"
# model = tf.keras.models.load_model(MODEL_PATH)
#
# def _real_predict(image: Image.Image) -> tuple[str, float]:
#     img = image.resize((224, 224)).convert("RGB")
#     arr = np.array(img) / 255.0
#     arr = np.expand_dims(arr, axis=0)
#     preds = model.predict(arr)[0]
#     idx = int(np.argmax(preds))
#     confidence = float(preds[idx])
#     return CLASS_NAMES[idx], confidence
# ---------------------------------------------------------------------


def _dummy_predict(image: Image.Image) -> tuple[str, float]:
    """
    Placeholder inference: picks a class based on simple image stats
    (deterministic-ish, not random garbage) so the API behaves consistently
    for the same image, until a real model is plugged in.
    """
    img = image.resize((64, 64)).convert("RGB")
    arr = np.array(img)
    avg_brightness = arr.mean()
    avg_green = arr[:, :, 1].mean()

    # crude heuristic just so results vary sensibly by image content
    seed = int(avg_brightness + avg_green) % len(CLASS_NAMES)
    idx = seed
    confidence = round(random.uniform(0.78, 0.96), 4)

    return CLASS_NAMES[idx], confidence


def predict_disease(image_bytes: bytes) -> dict:
    """
    Main entrypoint. Takes raw image bytes, returns prediction + disease info.
    """
    image = Image.open(io.BytesIO(image_bytes))

    # Swap this line for _real_predict(image) once model is trained
    class_name, confidence = _dummy_predict(image)

    info = get_disease_info(class_name)

    return {
        "predicted_class": class_name,
        "confidence": confidence,
        "disease_name": info["disease_name"],
        "symptoms": info["symptoms"],
        "treatment": info["treatment"],
        "prevention": info["prevention"],
        "model_status": "dummy_inference"  # change to "trained_model" once real model is live
    }
